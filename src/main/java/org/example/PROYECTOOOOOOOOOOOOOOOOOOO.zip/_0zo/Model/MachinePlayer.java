package org.example._0zo.Model;

// Modelo para el jugador IA, hereda de Player
public class MachinePlayer extends Player {

    // Constructor
    public MachinePlayer(String name) {
        super(name); // Llama al constructor de Player
    }


    public Card findCardToPlay(Board board) {
        Card bestCardToPlay = null;


        for (Card card : hand) {
            if (board.CanPlayCard(card) && !card.getCardRank().equals("A")) {
                bestCardToPlay = card;
                break; // Encontramos una buena
            }
        }

        if (bestCardToPlay == null) {
            for (Card card : hand) {
                if (board.CanPlayCard(card)) {
                    bestCardToPlay = card;
                    break;
                }
            }
        }
        return bestCardToPlay;
    }
}