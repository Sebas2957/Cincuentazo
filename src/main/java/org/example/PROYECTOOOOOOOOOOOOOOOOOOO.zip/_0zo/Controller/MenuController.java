package org.example._0zo.Controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import org.example._0zo.MainApplication;

public class MenuController {

    @FXML
    private Button btnStart;

    @FXML
    private ComboBox<Integer> cmbNumRobots;

    private static int selectedNumMachines = 2; // Valor por defecto

    @FXML
    private void initialize() {
        // Configurar el ComboBox con opciones de 1 a 3 máquinas
        cmbNumRobots.getItems().addAll(1, 2, 3);
        cmbNumRobots.setValue(2); // Valor por defecto

        // Listener para cuando el usuario cambie la selección
        cmbNumRobots.setOnAction(event -> {
            selectedNumMachines = cmbNumRobots.getValue();
        });

        // Configurar el botón de inicio
        btnStart.setOnAction(event -> startGame());
    }

    private void startGame() {
        try {
            // Obtener el Stage actual
            Stage stage = (Stage) btnStart.getScene().getWindow();

            // Cargar la vista del juego
            FXMLLoader loader = new FXMLLoader(
                    MainApplication.class.getResource("hello-view.fxml")
            );

            Scene gameScene = new Scene(loader.load(), 609, 609);

            // Obtener el controlador del juego y pasarle el número de máquinas
            GameController gameController = loader.getController();
            gameController.setNumMachines(selectedNumMachines);

            // Cambiar la escena
            stage.setScene(gameScene);
            stage.setTitle("Cincuentazo - En Juego");

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al cargar la vista del juego: " + e.getMessage());
        }
    }

    public static int getSelectedNumMachines() {
        return selectedNumMachines;
    }
}