package org.example._0zo.Controller;

import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.HBox;
import javafx.util.Duration;
import org.example._0zo.Model.*;

import java.util.ArrayList;

public class GameController {

    // --- Game Configuration (Easy to modify) ---
    private static final int INITIAL_CARDS = 4;
    private int NUM_MACHINES = 2; // Ahora puede ser modificado
    private static final int MIN_MACHINE_DELAY = 2;
    private static final int MAX_MACHINE_DELAY = 4;

    // --- FXML Components ---
    @FXML private Label lblTableSum;
    @FXML private Label lblCurrentCard;
    @FXML private Label lblPlayerTurn;
    @FXML private HBox playerHandContainer;
    @FXML private ImageView imgActiveCard;

    // --- Game Model ---
    private Board board;
    private Deck deck;
    private ArrayList<MachinePlayer> players;
    private int currentPlayerIndex;
    private boolean gameIsOver;
    private boolean waitingForMachine;

    // --- Initialization ---

    @FXML
    public void initialize() {
        // No iniciar el juego aquí, esperar a que se configure NUM_MACHINES
    }

    /**
     * Método público para configurar el número de máquinas desde el MenuController
     */
    public void setNumMachines(int numMachines) {
        if (numMachines >= 1 && numMachines <= 3) {
            this.NUM_MACHINES = numMachines;
            startNewGame();
        } else {
            System.err.println("Número de máquinas inválido: " + numMachines);
            this.NUM_MACHINES = 2;
            startNewGame();
        }
    }

    private void startNewGame() {
        this.board = new Board();
        this.deck = new Deck();
        this.players = new ArrayList<>();
        this.currentPlayerIndex = 0;
        this.gameIsOver = false;
        this.waitingForMachine = false;

        setupPlayers();
        dealInitialCards();
        updateUI();

        checkCurrentPlayer();
    }

    private void setupPlayers() {
        players.add(new MachinePlayer("Human"));

        for (int i = 1; i <= NUM_MACHINES; i++) {
            players.add(new MachinePlayer("Machine " + i));
        }
    }

    private void dealInitialCards() {
        // Deal cards to all players
        for (int i = 0; i < INITIAL_CARDS; i++) {
            for (MachinePlayer player : players) {
                if (!deck.isEmpty()) {
                    player.addCard(deck.getCard());
                }
            }
        }

        // Place initial card on board
        if (!deck.isEmpty()) {
            Card initialCard = deck.getCard();
            board.PlaceCard(initialCard);
            System.out.println("Initial card: " + initialCard);
            System.out.println("Initial sum: " + board.GetTotalSum());
        }
    }

    // --- Human Player Logic ---

    private void handleHumanCardClick(Card cardSelected) {
        if (currentPlayerIndex != 0 || gameIsOver || waitingForMachine) {
            return;
        }

        MachinePlayer humanPlayer = players.get(0);

        if (board.CanPlayCard(cardSelected)) {
            playCard(humanPlayer, cardSelected);
            updateUI();
            passTurn();
        } else {
            System.out.println("Invalid play. Would exceed 50.");
        }
    }

    // --- Machine Player Logic ---

    private void playMachineTurn(MachinePlayer machine) {
        waitingForMachine = true;
        lblPlayerTurn.setText("Turn: " + machine.getName() + " (Thinking...)");

        int delaySeconds = MIN_MACHINE_DELAY + (int)(Math.random() * (MAX_MACHINE_DELAY - MIN_MACHINE_DELAY + 1));

        PauseTransition pause = new PauseTransition(Duration.seconds(delaySeconds));
        pause.setOnFinished(event -> {
            if (gameIsOver) {
                return;
            }

            Card cardToPlay = machine.findCardToPlay(board);

            if (cardToPlay != null) {
                playCard(machine, cardToPlay);
                System.out.println(machine.getName() + " played " + cardToPlay);
            }

            waitingForMachine = false;
            updateUI();
            passTurn();
        });

        pause.play();
    }

    // --- Core Game Logic ---

    private void playCard(MachinePlayer player, Card card) {
        board.PlaceCard(card);
        player.removeCard(card);
        drawCardForPlayer(player);
    }

    private void drawCardForPlayer(MachinePlayer player) {
        if (deck.isEmpty()) {
            recycleDeck();
        }

        if (!deck.isEmpty()) {
            player.addCard(deck.getCard());
        }
    }

    private void recycleDeck() {
        System.out.println("--- Recycling deck ---");
        ArrayList<Card> recycledCards = board.RecycleCards();
        deck.AddCards(recycledCards);
        deck.ShuffleDeck();
    }

    // --- Turn Management ---

    private void passTurn() {
        if (gameIsOver) {
            return;
        }

        if (checkWinCondition()) {
            return;
        }

        findNextPlayer();
        checkCurrentPlayer();
    }

    private void findNextPlayer() {
        do {
            currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
        } while (players.get(currentPlayerIndex).isEliminated());
    }

    private void checkCurrentPlayer() {
        if (gameIsOver) {
            return;
        }

        MachinePlayer currentPlayer = players.get(currentPlayerIndex);
        lblPlayerTurn.setText("Turn: " + currentPlayer.getName());

        if (!currentPlayer.canPlay(board)) {
            eliminatePlayer(currentPlayer);
            passTurn();
            return;
        }

        if (currentPlayerIndex != 0) {
            playMachineTurn(currentPlayer);
        }
    }

    private boolean checkWinCondition() {
        int activePlayers = 0;
        MachinePlayer winner = null;

        for (MachinePlayer p : players) {
            if (!p.isEliminated()) {
                activePlayers++;
                winner = p;
            }
        }

        if (activePlayers <= 1) {
            endGame(winner);
            return true;
        }

        return false;
    }

    private void eliminatePlayer(MachinePlayer player) {
        player.eliminate();
        System.out.println("PLAYER ELIMINATED: " + player.getName() + "!");

        ArrayList<Card> cardsToReturn = player.returnAllCards();
        deck.AddCards(cardsToReturn);
        deck.ShuffleDeck();
    }

    private void endGame(MachinePlayer winner) {
        gameIsOver = true;
        if (winner != null) {
            lblPlayerTurn.setText("Game Over!");
            lblTableSum.setText("WINNER: " + winner.getName());
        } else {
            lblPlayerTurn.setText("Game Over!");
            lblTableSum.setText("Error: No winner found.");
        }
        playerHandContainer.getChildren().clear();
    }

    // --- UI Update Methods ---

    private void updateUI() {
        if (gameIsOver) {
            return;
        }

        updateTableSum();
        updateActiveCard();
        renderPlayerHand();
    }

    private void updateTableSum() {
        lblTableSum.setText("Sum: " + board.GetTotalSum());
    }

    private void updateActiveCard() {
        Card activeCard = board.GetActiveCard();

        if (activeCard != null) {
            lblCurrentCard.setText(activeCard.toString());
            displayCardImage(activeCard, imgActiveCard);
        } else {
            lblCurrentCard.setText("Empty table");
            imgActiveCard.setVisible(false);
        }
    }

    private void displayCardImage(Card card, ImageView imageView) {
        String imagePath = getCardImagePath(card);

        try {
            Image cardImage = new Image(getClass().getResourceAsStream(imagePath));
            imageView.setImage(cardImage);
            imageView.setVisible(true);
        } catch (Exception e) {
            imageView.setVisible(false);
        }
    }

    private void renderPlayerHand() {
        playerHandContainer.getChildren().clear();
        MachinePlayer humanPlayer = players.get(0);

        for (Card card : humanPlayer.getHand()) {
            StackPane cardContainer = createCardContainer(card);
            playerHandContainer.getChildren().add(cardContainer);
        }
    }

    private StackPane createCardContainer(Card card) {
        StackPane cardContainer = new StackPane();
        cardContainer.setPrefSize(80, 120);
        cardContainer.setStyle("-fx-cursor: hand;");

        addCardVisual(cardContainer, card);
        addCardHoverEffect(cardContainer);
        addCardClickHandler(cardContainer, card);

        if (!board.CanPlayCard(card)) {
            cardContainer.setOpacity(0.4);
            cardContainer.setDisable(true);
        }

        return cardContainer;
    }

    private void addCardVisual(StackPane container, Card card) {
        String imagePath = getCardImagePath(card);

        try {
            Image image = new Image(getClass().getResourceAsStream(imagePath));
            ImageView cardImage = new ImageView(image);
            cardImage.setFitWidth(80);
            cardImage.setFitHeight(120);
            cardImage.setPreserveRatio(true);
            container.getChildren().add(cardImage);
        } catch (Exception e) {
            Label cardLabel = new Label(card.getCardRank());
            cardLabel.setStyle(
                    "-fx-background-color: white;" +
                            "-fx-border-color: black;" +
                            "-fx-border-width: 2;" +
                            "-fx-font-size: 18px;" +
                            "-fx-font-weight: bold;" +
                            "-fx-alignment: center;" +
                            "-fx-pref-width: 80;" +
                            "-fx-pref-height: 120;"
            );
            container.getChildren().add(cardLabel);
        }
    }

    private void addCardHoverEffect(StackPane container) {
        container.setOnMouseEntered(event -> {
            container.setScaleX(1.15);
            container.setScaleY(1.15);
        });

        container.setOnMouseExited(event -> {
            container.setScaleX(1.0);
            container.setScaleY(1.0);
        });
    }

    private void addCardClickHandler(StackPane container, Card card) {
        container.setOnMouseClicked(event -> handleHumanCardClick(card));
    }

    private String getCardImagePath(Card card) {
        String rank = card.getCardRank();
        String cardName = card.getCardName().toLowerCase();

        String suitName = switch (cardName) {
            case "cups" -> "heart";
            case "swords" -> "spade";
            case "coins" -> "diamond";
            case "sticks" -> "club";
            default -> cardName;
        };

        String fileName;
        if (rank.equals("A")) {
            fileName = "as_" + suitName + ".png";
        } else if (rank.equals("10") && suitName.equals("club")) {
            fileName = "10_clubs.png";
        } else {
            fileName = rank + "_" + suitName + ".png";
        }

        return "/org/example/_0zo/imagenes/" + fileName;
    }
}